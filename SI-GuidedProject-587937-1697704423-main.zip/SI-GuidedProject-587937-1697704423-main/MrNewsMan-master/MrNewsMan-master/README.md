# MrNewsMan-master


* Android App for displaying News written in Kotlin-Native <br>
* Fetch news from API and list them inside a RecyclerView  <br>
* Used RecyclerView, Chrome Web View, API, MVP  <br>


<p align="left">

<img src="https://user-images.githubusercontent.com/50077510/127983613-53221e1f-8288-427e-a481-ef966ed63d9d.jpg" width="200" height="400">

<img src="https://user-images.githubusercontent.com/50077510/127982481-27d45ba8-243e-4c25-aff7-12a881812460.gif" width="200" height="400">

</p>
